﻿var objetoBoot = new Object();
objetoBoot.DivSite = "#conteudoBoot";
objetoBoot.listaBoots = [];

objetoBoot.LabelPontos = "#Pontos";
objetoBoot.labelPontosRestante = "#PontosRestante";

objetoBoot.pontos = 0;
objetoBoot.vidas = 10;
objetoBoot.UltimoIdGerado = 0;


class Boot {
    constructor(window, $) {
        this._window = window;
        this._jquery = $;
    }

    inicilizarClasse(id, idDiv) {
        this.id = id;
        this.idDiv = idDiv;
        this.CriaBoot(this);
    }

    CriaBoot(Boot) {
        var divBoot = $("<div>").attr({ id: Boot.idDiv, class: "col-md-3 classDivBoot" });
        $(objetoBoot.DivSite).append(divBoot);
    }
}

function AdicionarFuncaoBotao() {
    $("#AdicionarBoot").click(function () {

        var idDiv = Math.floor(Math.random() * 1000 + 1);
        AdicionarBoot(1, idDiv);

        var carregaUltimo = 1;

        if (objetoBoot.UltimoIdGerado != 0) {
            carregaUltimo = VerificaAlinhamentoBoots(idDiv);
        }

        if (carregaUltimo > 0) {
            objetoBoot.UltimoIdGerado = idDiv;
        }

    });

    $("#LimparBoot").click(function () {
        $(objetoBoot.DivSite).html("");
    });
}

function VerificaAlinhamentoBoots(idDivGerado) {
    var retorno = 1;
    var posicaoUltimaDiv = pegarPosicaoRotacao(objetoBoot.UltimoIdGerado);
    var posicaoDivAtual = pegarPosicaoRotacao(idDivGerado);

    if (posicaoUltimaDiv != posicaoDivAtual) {
        objetoBoot.vidas--;
    }
    else {
        objetoBoot.pontos++;
    }

    if (objetoBoot.vidas == 0) {

        alert("Você perdeu! O Jogo será reinicializado.");

        objetoBoot.vidas = 10;
        objetoBoot.pontos = 0;
        objetoBoot.UltimoIdGerado = 0;
        $(objetoBoot.DivSite).html("");

        retorno = 0;
    }

    Pontos();

    return retorno;
}

function pegarPosicaoRotacao(idDiv) {
    var el = document.getElementById(idDiv);
    var st = window.getComputedStyle(el, null);
    var tr = st.getPropertyValue("-webkit-transform") ||
        st.getPropertyValue("-moz-transform") ||
        st.getPropertyValue("-ms-transform") ||
        st.getPropertyValue("-o-transform") ||
        st.getPropertyValue("transform") ||
        "fail...";

    if (tr !== "none") {

        var values = tr.split('(')[1];
        values = values.split(')')[0];
        values = values.split(',');

        var b = values[1];

        return Math.round(b, 500);
    }
}

function AdicionarBoot(id, idDiv) {
    var idClasse = objetoBoot.listaBoots.push(new Boot(window, jQuery, id, idDiv)) - 1;
    objetoBoot.listaBoots[idClasse].inicilizarClasse(id, idDiv);
}

function Pontos() {
    $(objetoBoot.LabelPontos).text(objetoBoot.pontos);
    $(objetoBoot.labelPontosRestante).text(objetoBoot.vidas);
}

$(function () {
    AdicionarFuncaoBotao();
    Pontos();
});